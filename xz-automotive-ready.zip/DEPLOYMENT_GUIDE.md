# XZ Automotive - Complete Deployment Guide

## 🎯 Deployment Checklist

### Pre-Deployment
- [ ] All code committed to Git
- [ ] Environment variables configured
- [ ] Database backup created
- [ ] SSL certificate obtained
- [ ] Domain name registered
- [ ] Email service configured
- [ ] Payment gateway tested
- [ ] All tests passing

---

## 🌐 Domain & DNS Setup

### 1. Register Domain
- **Providers**: GoDaddy, Namecheap, Google Domains
- **Recommended**: xz-automotive.com
- **Cost**: $10-15/year

### 2. Configure DNS Records
```
Type    Name                Value
A       @                   your-server-ip
A       www                 your-server-ip
CNAME   api                 your-app-url
MX      @                   mail-server
TXT     @                   v=spf1 include:sendgrid.net ~all
```

### 3. SSL Certificate
**Option A: Let's Encrypt (Free)**
```bash
sudo apt-get install certbot
sudo certbot certonly --standalone -d xz-automotive.com -d www.xz-automotive.com
```

**Option B: Paid Certificate**
- Comodo, DigiCert, GeoTrust
- Usually $50-200/year
- Includes warranty & support

---

## 🚀 Deployment Options

### Option 1: Heroku (Easiest)

#### Step 1: Prepare
```bash
# Install Heroku CLI
npm install -g heroku

# Login
heroku login
```

#### Step 2: Create App
```bash
# Create new app
heroku create xz-automotive

# Or connect existing app
heroku git:remote -a xz-automotive
```

#### Step 3: Configure Environment
```bash
heroku config:set NODE_ENV=production
heroku config:set MONGODB_URI=mongodb+srv://user:pass@cluster.mongodb.net/xz-automotive
heroku config:set STRIPE_SECRET_KEY=sk_live_xxxxx
heroku config:set SMTP_USER=your-email@gmail.com
heroku config:set SMTP_PASS=your-app-password
heroku config:set JWT_SECRET=your-super-secret-key
```

#### Step 4: Deploy
```bash
git push heroku main
```

#### Step 5: View Logs
```bash
heroku logs --tail
```

#### Step 6: Custom Domain
```bash
heroku domains:add xz-automotive.com
```

**Pros**: Easy, automatic SSL, built-in monitoring
**Cons**: $7-50/month, limited customization
**Best for**: Startups, MVPs

---

### Option 2: Railway (Modern Alternative)

#### Step 1: Connect GitHub
1. Go to https://railway.app
2. Click "New Project"
3. Select "Deploy from GitHub"
4. Authorize and select repository

#### Step 2: Configure
1. Add environment variables
2. Set build command: `npm install`
3. Set start command: `npm start`

#### Step 3: Deploy
- Automatic deployment on push to main
- View logs in dashboard

**Pros**: Modern UI, good pricing, GitHub integration
**Cons**: Newer platform, less community support
**Cost**: $5-50/month

---

### Option 3: DigitalOcean (Full Control)

#### Step 1: Create Droplet
1. Go to https://digitalocean.com
2. Create new Droplet
3. Select: Ubuntu 22.04 LTS, $6/month plan
4. Add SSH key

#### Step 2: SSH into Server
```bash
ssh root@your-droplet-ip
```

#### Step 3: Install Dependencies
```bash
# Update system
apt-get update && apt-get upgrade -y

# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
apt-get install -y nodejs

# Install MongoDB
apt-get install -y mongodb-org

# Install Nginx
apt-get install -y nginx

# Install PM2
npm install -g pm2
```

#### Step 4: Clone Repository
```bash
cd /var/www
git clone https://github.com/yourusername/xz-automotive.git
cd xz-automotive
npm install
```

#### Step 5: Configure Environment
```bash
nano .env
# Add your configuration
```

#### Step 6: Start Application
```bash
pm2 start server.js --name "xz-api"
pm2 startup
pm2 save
```

#### Step 7: Configure Nginx
```bash
sudo nano /etc/nginx/sites-available/default
```

```nginx
server {
    listen 80;
    server_name xz-automotive.com www.xz-automotive.com;

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

```bash
sudo nginx -t
sudo systemctl restart nginx
```

#### Step 8: SSL Certificate
```bash
apt-get install -y certbot python3-certbot-nginx
certbot --nginx -d xz-automotive.com -d www.xz-automotive.com
```

**Pros**: Full control, affordable, good performance
**Cons**: Manual setup, requires Linux knowledge
**Cost**: $6-48/month

---

### Option 4: AWS (Enterprise)

#### Step 1: EC2 Instance
1. Launch EC2 instance (t3.micro - free tier)
2. Select Ubuntu 22.04 LTS
3. Configure security groups (allow 80, 443, 22)

#### Step 2: RDS Database
1. Create RDS instance (MongoDB Atlas recommended instead)
2. Configure security groups

#### Step 3: Application Load Balancer
1. Create ALB
2. Configure target groups
3. Attach EC2 instances

#### Step 4: CloudFront CDN
1. Create distribution
2. Set origin to ALB
3. Configure SSL

#### Step 5: Route 53 DNS
1. Create hosted zone
2. Add A record pointing to CloudFront

**Pros**: Scalable, reliable, enterprise features
**Cons**: Complex, expensive ($20-500+/month)
**Best for**: Large applications

---

## 🔒 Security Hardening

### 1. Firewall Configuration
```bash
# DigitalOcean UFW
ufw allow 22/tcp
ufw allow 80/tcp
ufw allow 443/tcp
ufw enable
```

### 2. Fail2Ban (Brute Force Protection)
```bash
apt-get install fail2ban
systemctl enable fail2ban
```

### 3. Automatic Updates
```bash
apt-get install unattended-upgrades
dpkg-reconfigure -plow unattended-upgrades
```

### 4. Monitor Logs
```bash
# View application logs
pm2 logs

# View system logs
journalctl -u nginx -f
```

---

## 📊 Monitoring & Alerts

### Option 1: PM2 Plus
```bash
pm2 plus
```

### Option 2: New Relic
```bash
npm install newrelic
```

### Option 3: DataDog
```bash
# Install agent
DD_AGENT_MAJOR_VERSION=7 DD_API_KEY=your-key DD_SITE=datadoghq.com bash -c "$(curl -L https://s3.amazonaws.com/dd-agent/scripts/install_agent.sh)"
```

---

## 🔄 Continuous Deployment

### GitHub Actions
Create `.github/workflows/deploy.yml`:

```yaml
name: Deploy to Production

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Setup Node.js
        uses: actions/setup-node@v3
        with:
          node-version: '18'
      
      - name: Install dependencies
        run: npm install
      
      - name: Run tests
        run: npm test
      
      - name: Deploy to Heroku
        uses: akhileshns/heroku-deploy@v3.12.12
        with:
          heroku_api_key: ${{ secrets.HEROKU_API_KEY }}
          heroku_app_name: "xz-automotive"
          heroku_email: ${{ secrets.HEROKU_EMAIL }}
```

---

## 📦 Database Migration

### MongoDB Atlas (Cloud)
1. Create account at https://mongodb.com/cloud
2. Create cluster
3. Get connection string
4. Add to .env:
```env
MONGODB_URI=mongodb+srv://user:pass@cluster.mongodb.net/xz-automotive
```

### Backup & Restore
```bash
# Backup
mongodump --uri "mongodb+srv://user:pass@cluster.mongodb.net/xz-automotive" --out ./backup

# Restore
mongorestore --uri "mongodb+srv://user:pass@cluster.mongodb.net/xz-automotive" ./backup
```

---

## 🔍 Performance Optimization

### 1. Enable Compression
```javascript
import compression from 'compression';
app.use(compression());
```

### 2. Caching Headers
```javascript
app.use((req, res, next) => {
  res.set('Cache-Control', 'public, max-age=3600');
  next();
});
```

### 3. CDN Integration
- Cloudflare (Free)
- AWS CloudFront
- Akamai

### 4. Database Indexing
```javascript
modelSchema.index({ slug: 1 });
contactSchema.index({ email: 1 });
```

---

## 📋 Post-Deployment Checklist

- [ ] Website loads correctly
- [ ] SSL certificate working
- [ ] Contact form sending emails
- [ ] Payment gateway processing
- [ ] Analytics tracking
- [ ] SEO tags visible
- [ ] Mobile responsive
- [ ] Performance acceptable
- [ ] Error logging working
- [ ] Backups scheduled
- [ ] Monitoring alerts active
- [ ] DNS records correct
- [ ] Email deliverability good
- [ ] Database backups verified
- [ ] Security headers set

---

## 🆘 Troubleshooting Deployment

### Application Won't Start
```bash
# Check logs
heroku logs --tail

# Restart
heroku restart
```

### Database Connection Failed
```bash
# Verify connection string
echo $MONGODB_URI

# Test connection
mongosh "your-connection-string"
```

### Email Not Sending
- Check SMTP credentials
- Verify sender email
- Check spam folder
- Review email logs

### SSL Certificate Error
```bash
# Renew certificate
certbot renew

# Force renewal
certbot renew --force-renewal
```

---

## 📞 Support Resources

- **Heroku Docs**: https://devcenter.heroku.com
- **Railway Docs**: https://docs.railway.app
- **DigitalOcean Docs**: https://docs.digitalocean.com
- **AWS Docs**: https://docs.aws.amazon.com
- **MongoDB Docs**: https://docs.mongodb.com
- **Let's Encrypt**: https://letsencrypt.org

---

**Last Updated**: April 2026
**Version**: 1.0.0

