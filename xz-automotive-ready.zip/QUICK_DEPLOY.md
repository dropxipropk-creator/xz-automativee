# ⚡ INSTANT DEPLOYMENT GUIDE - 2 MINUTES

## 🚀 Deploy to Railway (Fastest)

### Step 1: Push to GitHub
```bash
cd /home/ubuntu/xz-automotive

# Create GitHub repo (if you don't have one)
# Go to https://github.com/new

# Add remote
git remote add origin https://github.com/YOUR_USERNAME/xz-automotive.git
git branch -M main
git push -u origin main
```

### Step 2: Deploy on Railway
1. Go to https://railway.app
2. Click "New Project"
3. Select "Deploy from GitHub"
4. Authorize GitHub
5. Select "xz-automotive" repository
6. Click "Deploy"

### Step 3: Add Environment Variables
In Railway Dashboard:
1. Click on your project
2. Go to "Variables"
3. Add:
```
NODE_ENV=production
MONGODB_URI=mongodb+srv://user:pass@cluster.mongodb.net/xz-automotive
STRIPE_SECRET_KEY=sk_test_xxxxx
JWT_SECRET=your-secret-key-here
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-app-password
```

### Step 4: Done! 🎉
- Your app is live at: `https://xz-automotive-xxxxx.railway.app`
- Railway auto-deploys on every push to main

---

## 🌐 Get Custom Domain
1. In Railway Dashboard → Domains
2. Add custom domain: `xz-automotive.com`
3. Update DNS at your registrar
4. SSL auto-configured ✅

---

## 💰 Pricing
- **Free Tier**: $5 credit/month (perfect for MVP)
- **Paid**: $5-50/month as you scale

---

## 📊 Monitoring
- View logs: Railway Dashboard
- Monitor performance: Built-in metrics
- Set alerts: Email notifications

---

**That's it! Your website is LIVE! 🚀**
