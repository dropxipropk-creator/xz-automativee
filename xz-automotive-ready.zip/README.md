# XZ Automotive - Premium Luxury Car Website

A complete, production-ready full-stack website for XZ luxury automotive brand with backend API, database, payment processing, and enterprise features.

## 📋 Features

### Frontend
- ✅ Premium BMW-inspired design system
- ✅ Responsive layout (mobile, tablet, desktop)
- ✅ Full-bleed automotive photography
- ✅ Smooth animations and interactions
- ✅ SEO-optimized HTML structure
- ✅ Google Fonts integration
- ✅ Contact form with validation

### Backend
- ✅ Express.js REST API
- ✅ MongoDB database integration
- ✅ User authentication & authorization
- ✅ Contact form processing
- ✅ Email notifications (Nodemailer)
- ✅ Stripe payment gateway
- ✅ Newsletter subscription
- ✅ Blog system
- ✅ Analytics tracking

### Security
- ✅ Helmet.js security headers
- ✅ CORS protection
- ✅ Rate limiting
- ✅ Input validation & sanitization
- ✅ JWT authentication
- ✅ Password hashing (bcryptjs)
- ✅ SSL/TLS ready

### DevOps
- ✅ Environment configuration (.env)
- ✅ Docker support (optional)
- ✅ Git version control
- ✅ Automated backups
- ✅ Monitoring & logging

---

## 🚀 Quick Start

### Prerequisites
- Node.js 16+ 
- npm or yarn
- MongoDB (Atlas or local)
- Git

### Local Development

1. **Clone the repository**
```bash
git clone https://github.com/yourusername/xz-automotive.git
cd xz-automotive
```

2. **Install dependencies**
```bash
npm install
```

3. **Create environment file**
```bash
cp .env.example .env
```

4. **Configure .env file**
Edit `.env` with your credentials:
```env
MONGODB_URI=mongodb+srv://user:pass@cluster.mongodb.net/xz-automotive
STRIPE_SECRET_KEY=sk_test_xxxxx
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-app-password
```

5. **Start development server**
```bash
npm run dev
```

6. **Access the application**
- Frontend: http://localhost:3000
- API: http://localhost:5000
- API Docs: http://localhost:5000/api/docs

---

## 📁 Project Structure

```
xz-automotive/
├── index.html              # Frontend HTML
├── server.js               # Express API server
├── models/
│   └── index.js           # MongoDB schemas
├── routes/
│   ├── models.js          # Car models API
│   ├── contact.js         # Contact form API
│   ├── orders.js          # Orders API
│   └── payments.js        # Stripe API
├── middleware/
│   ├── auth.js            # JWT authentication
│   ├── validation.js      # Input validation
│   └── errorHandler.js    # Error handling
├── utils/
│   ├── email.js           # Email templates
│   ├── stripe.js          # Stripe helpers
│   └── logger.js          # Logging
├── .env.example           # Environment template
├── package.json           # Dependencies
└── README.md              # Documentation
```

---

## 🔌 API Endpoints

### Models
```
GET    /api/models              # Get all models
GET    /api/models/:slug        # Get single model
POST   /api/models              # Create model (admin)
PUT    /api/models/:id          # Update model (admin)
DELETE /api/models/:id          # Delete model (admin)
```

### Contact
```
POST   /api/contact             # Submit contact form
GET    /api/contact             # Get all messages (admin)
PUT    /api/contact/:id         # Mark as read (admin)
```

### Orders
```
POST   /api/orders              # Create order
GET    /api/orders              # Get user orders
GET    /api/orders/:id          # Get order details
PUT    /api/orders/:id/status   # Update status (admin)
```

### Payments
```
POST   /api/create-payment-intent    # Create Stripe payment
POST   /api/webhook/stripe           # Stripe webhook
```

### Newsletter
```
POST   /api/subscribe           # Subscribe to newsletter
POST   /api/unsubscribe         # Unsubscribe
```

### Blog
```
GET    /api/blog                # Get all posts
GET    /api/blog/:slug          # Get single post
POST   /api/blog                # Create post (admin)
```

### SEO
```
GET    /sitemap.xml             # XML sitemap
GET    /robots.txt              # Robots file
```

---

## 🔐 Security Features

### Implemented
- **Helmet.js**: Security headers (CSP, X-Frame-Options, etc.)
- **CORS**: Cross-origin resource sharing protection
- **Rate Limiting**: Prevent brute force attacks
- **Input Validation**: Express-validator for all inputs
- **Password Hashing**: bcryptjs for secure passwords
- **JWT**: Secure token-based authentication
- **HTTPS**: SSL/TLS ready

### Deployment Security
- Use environment variables for secrets
- Enable HTTPS/SSL certificate
- Configure firewall rules
- Set up regular backups
- Monitor logs for suspicious activity
- Use strong database passwords

---

## 💳 Payment Integration (Stripe)

### Setup
1. Create Stripe account at https://stripe.com
2. Get API keys from dashboard
3. Add to .env:
```env
STRIPE_PUBLIC_KEY=pk_test_xxxxx
STRIPE_SECRET_KEY=sk_test_xxxxx
```

### Usage
```javascript
// Create payment intent
POST /api/create-payment-intent
{
  "amount": 99.99,
  "currency": "usd"
}

// Response
{
  "clientSecret": "pi_xxxxx_secret_xxxxx"
}
```

---

## 📧 Email Setup

### Gmail (Recommended)
1. Enable 2-factor authentication
2. Generate app password
3. Add to .env:
```env
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-app-password
```

### SendGrid (Alternative)
```env
SMTP_HOST=smtp.sendgrid.net
SMTP_PORT=587
SMTP_USER=apikey
SMTP_PASS=SG.xxxxx
```

---

## 📊 Analytics & SEO

### Google Analytics
1. Create property at https://analytics.google.com
2. Get Measurement ID
3. Add to frontend:
```html
<script async src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXXXXX"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-XXXXXXXXXX');
</script>
```

### SEO Meta Tags
All pages include:
- Title tags
- Meta descriptions
- Open Graph tags
- Twitter Card tags
- Structured data (Schema.org)

### Sitemap & Robots
- `/sitemap.xml` - XML sitemap for search engines
- `/robots.txt` - Crawler instructions

---

## 🌐 Deployment

### Option 1: Heroku (Recommended for beginners)

1. **Install Heroku CLI**
```bash
npm install -g heroku
heroku login
```

2. **Create Heroku app**
```bash
heroku create xz-automotive
```

3. **Set environment variables**
```bash
heroku config:set MONGODB_URI=your_uri
heroku config:set STRIPE_SECRET_KEY=your_key
heroku config:set SMTP_USER=your_email
heroku config:set SMTP_PASS=your_password
```

4. **Deploy**
```bash
git push heroku main
```

5. **View logs**
```bash
heroku logs --tail
```

### Option 2: Railway

1. Connect GitHub repository
2. Create new project
3. Add environment variables
4. Deploy automatically

### Option 3: DigitalOcean / AWS / VPS

1. Create server instance
2. Install Node.js and MongoDB
3. Clone repository
4. Install dependencies
5. Start with PM2 or systemd
6. Configure Nginx as reverse proxy
7. Set up SSL with Let's Encrypt

---

## 🔄 Continuous Integration / Deployment

### GitHub Actions Example
```yaml
name: Deploy

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - uses: actions/setup-node@v2
        with:
          node-version: '16'
      - run: npm install
      - run: npm test
      - run: git push heroku main
```

---

## 📦 Database Backup

### MongoDB Atlas (Cloud)
- Automatic daily backups
- Point-in-time recovery
- Manual snapshots available

### Local MongoDB
```bash
# Backup
mongodump --uri "mongodb://localhost:27017/xz-automotive" --out ./backup

# Restore
mongorestore --uri "mongodb://localhost:27017/xz-automotive" ./backup
```

---

## 🛠️ Development Tools

### Recommended IDE
- **VS Code** with extensions:
  - ES7+ React/Redux/React-Native snippets
  - MongoDB for VS Code
  - Thunder Client (API testing)
  - Prettier (code formatter)

### Testing
```bash
npm test
```

### Linting
```bash
npm run lint
```

### Build for Production
```bash
npm run build
```

---

## 📋 Environment Checklist

Before deploying to production:

- [ ] Change all default passwords
- [ ] Set `NODE_ENV=production`
- [ ] Enable HTTPS/SSL
- [ ] Configure firewall rules
- [ ] Set up database backups
- [ ] Enable rate limiting
- [ ] Configure CORS properly
- [ ] Set up monitoring & alerts
- [ ] Enable logging
- [ ] Test payment gateway
- [ ] Test email notifications
- [ ] Verify SEO tags
- [ ] Test on mobile devices
- [ ] Performance optimization
- [ ] Security audit

---

## 🆘 Troubleshooting

### MongoDB Connection Error
```
Error: connect ECONNREFUSED 127.0.0.1:27017
```
**Solution**: Ensure MongoDB is running or check connection string in .env

### Port Already in Use
```
Error: listen EADDRINUSE: address already in use :::5000
```
**Solution**: 
```bash
lsof -i :5000
kill -9 <PID>
```

### Email Not Sending
**Solution**: 
- Check SMTP credentials
- Enable "Less secure apps" for Gmail
- Check firewall/antivirus blocking
- Verify sender email is correct

### Stripe Payment Failing
**Solution**:
- Use test card: 4242 4242 4242 4242
- Check API keys in .env
- Verify webhook endpoint

---

## 📞 Support & Resources

- **Documentation**: Full API docs at `/api/docs`
- **GitHub Issues**: Report bugs on GitHub
- **Email**: support@xz-automotive.com
- **Stripe Docs**: https://stripe.com/docs
- **MongoDB Docs**: https://docs.mongodb.com
- **Express Docs**: https://expressjs.com

---

## 📄 License

MIT License - See LICENSE file for details

---

## 👥 Contributors

- **Design**: XZ Studio Design Team
- **Development**: XZ Development Team
- **Deployment**: DevOps Team

---

**Last Updated**: April 2026
**Version**: 1.0.0
**Status**: Production Ready ✅

