import mongoose from 'mongoose';

// User Schema
const userSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true, lowercase: true },
  password: { type: String, required: true },
  phone: String,
  address: String,
  role: { type: String, enum: ['user', 'admin'], default: 'user' },
  createdAt: { type: Date, default: Date.now }
});

// Model Schema
const modelSchema = new mongoose.Schema({
  name: { type: String, required: true },
  slug: { type: String, required: true, unique: true },
  description: String,
  specifications: {
    horsepower: Number,
    acceleration: String,
    topSpeed: String,
    range: String
  },
  price: Number,
  image: String,
  gallery: [String],
  featured: { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now }
});

// Contact Message Schema
const contactSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true },
  phone: String,
  subject: String,
  message: { type: String, required: true },
  status: { type: String, enum: ['new', 'read', 'replied'], default: 'new' },
  createdAt: { type: Date, default: Date.now }
});

// Order Schema
const orderSchema = new mongoose.Schema({
  orderNumber: { type: String, unique: true },
  userId: mongoose.Schema.Types.ObjectId,
  model: { type: String, required: true },
  quantity: { type: Number, default: 1 },
  totalPrice: Number,
  status: { type: String, enum: ['pending', 'confirmed', 'shipped', 'delivered'], default: 'pending' },
  paymentStatus: { type: String, enum: ['unpaid', 'paid', 'refunded'], default: 'unpaid' },
  stripePaymentId: String,
  shippingAddress: {
    street: String,
    city: String,
    state: String,
    zip: String,
    country: String
  },
  createdAt: { type: Date, default: Date.now }
});

// Newsletter Subscription Schema
const subscriptionSchema = new mongoose.Schema({
  email: { type: String, required: true, unique: true, lowercase: true },
  subscribedAt: { type: Date, default: Date.now },
  unsubscribed: { type: Boolean, default: false }
});

// Blog Post Schema
const blogSchema = new mongoose.Schema({
  title: { type: String, required: true },
  slug: { type: String, required: true, unique: true },
  content: String,
  author: String,
  image: String,
  published: { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

// Analytics Schema
const analyticsSchema = new mongoose.Schema({
  pageUrl: String,
  userAgent: String,
  ipAddress: String,
  referrer: String,
  timestamp: { type: Date, default: Date.now }
});

export const User = mongoose.model('User', userSchema);
export const Model = mongoose.model('Model', modelSchema);
export const Contact = mongoose.model('Contact', contactSchema);
export const Order = mongoose.model('Order', orderSchema);
export const Subscription = mongoose.model('Subscription', subscriptionSchema);
export const Blog = mongoose.model('Blog', blogSchema);
export const Analytics = mongoose.model('Analytics', analyticsSchema);
